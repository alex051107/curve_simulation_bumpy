import unittest


class test_append(unittest.TestCase):
    pass


class test_slice_pdb(unittest.TestCase):
    pass


class test_duplicate_laterally(unittest.TestCase):
    pass


# TODO: Remove or rework
class test_gen_slicepoint(unittest.TestCase):
    pass


class test_calc_residue_COMS(unittest.TestCase):
    pass


class test_rectangular_slice(unittest.TestCase):
    pass


class test_circular_slice(unittest.TestCase):
    pass
